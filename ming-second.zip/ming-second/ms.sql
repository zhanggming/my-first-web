SET NAMES UTF8;
DROP DATABASE IF  EXISTS ms;
CREATE DATABASE ms CHARSET=UTF8;
use ms;
/**创建表格**/
/**1.用户信息**/
   CREATE TABLE ms_user(
     uid INT PRIMARY KEY AUTO_INCREMENT,
		 uname VARCHAR(32),
		 upwd VARCHAR(32),
		 email VARCHAR(64),
		 phone VARCHAR(16),

		 avatar VARCHAR(128),     #头像图片路径
		 user_name VARCHAR(32),   #用户真实姓名
		 gender INT               #性别 0-女 1-男
   );
/**2.首页轮播图**/
   CREATE TABLE ms_index_carousel(
	   cid INT PRIMARY KEY AUTO_INCREMENT,
		 img VARCHAR(128),
		 title VARCHAR(64),
		 href VARCHAR(128)
	 );
/**3.首页内容**/
   CREATE TABLE ms_index_count(
	   cid INT PRIMARY KEY AUTO_INCREMENT,
		 title VARCHAR(64),
		 details VARCHAR(128),
		 pic  VARCHAR(128),
		 href VARCHAR(128),
		 seq_recommended TINYINT,
		 seq_new_arrival TINYINT,
		 seq_top_hot TINYINT
	 );