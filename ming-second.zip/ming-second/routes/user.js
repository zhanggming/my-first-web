const express=require('express');
const pool=require('../pool.js');
//创建路由器
var router=express.Router();
//1.用户注册路由
     router.post('/register',(req,res)=>{
	     var obj=req.body;
		 var $uname=obj.uname,
			 $upwd=obj.upwd,
			 $email=obj.email,
			 $phone=obj.phone;
		 if (!$uname){
		     res.send({code:401,msg:'uname required'});
			 return;
		 }
		 if (!$upwd){
		     res.send({code:402,msg:'upwd required'});
			 return;
		 }
		 if (!$email){
		     res.send({code:403,msg:'email required'});
			 return;
		 }
		 if (!$phone){
		     res.send({code:404,msg:'phone required'});
			 return;
		 }
		 pool.query('INSERT INTO ms_user SET ?',[obj],(err,result)=>{
		     if (err) throw err;
			 if(result.affectedRows>0){
			     res.send({code:200,msg:'register sucess'});
			 }
		 });
	 });
//导出路由器
module.exports=router;
