const express=require('express');
const  bodyParser=require('body-parser');
const userRouter=require('./routes/user.js');

var server=express();
server.listen(3000);

//托管静态文件
server.use(express.static('public'));
//body解析post请求的数据
server.use(bodyParser.urlencoded({
     extended:false
}));
//路由器挂载
server.use('/user',userRouter);