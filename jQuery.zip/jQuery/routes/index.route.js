const express=require("express");
const router=express.Router();
const pool=require("../pool");


  router.get("/first",(req,res)=>{
    var sql=`select * from mll_index_product  where pid!=0 order by pid `;
    pool.query(sql,[],(err,result)=>{
      if(err) console.log(err);
      res.send(result);
    })
  })
 router.get("/carsousel",(req,res)=>{
    var sql=`select * from mll_index_carousel  where cid!=0 order by cid `;
      pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        res.send(result)
   })
  });  
      //1
  router.get("/firfloor",(req,res)=>{
    var sql=`select * from mll_index_Firstfloor where fid!=0 order by fid `;
    pool.query(sql,[],(err,result)=>{
     if(err) console.log(err);
     res.send(result)
     })
    }) 
    //2
     
  router.get("/secondfloor",(req,res)=>{
    var sql=`select * from mll_index_secondFloor  where tid!=0 order by tid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        res.send(result)
  })  
}) 
       //3
  router.get("/threefloor",(req,res)=>{
    var sql=`select * from   where kid!=0 order by kid`;
    pool.query(sql,[],(err,result)=>{
     if(err) console.log(err);
     res.send(result)
  })  
}) 
       //4
  router.get("/threetitle",(req,res)=>{
    var sql=`select m.title,k.img`;
    sql+=` from  mll_index_threeTitle m,mll_index_threeFloor k`;
    sql+=' where mid!=0 order by mid and where kid!=0 order by kid'
    pool.query(sql,[],(err,result)=>{
     if(err) console.log(err);
     res.send(result)
  })  
}) 
           
    //
  router.get("/threeproduct",(req,res)=>{
    var sql=`select * from mll_index_threeProduct  where nid!=0 order by nid`;
    pool.query(sql,[],(err,result)=>{
     if(err) console.log(err);
     res.send(result)
     })
   })     
//
  router.get("/lastfloor",(req,res)=>{
    var sql=`select * from mll_index_lastFloor where qid!=0 order by qid`;
    pool.query(sql,[],(err,result)=>{
     if(err) console.log(err);
     res.send(result)
    })    
  })      
  
  router.get("/lastProduct",(req,res)=>{
    var sql=`select * from mll_index_lastProduct  where vid!=0 order by vid`;
    pool.query(sql,[],(err,result)=>{
      if(err) console.log(err);
     res.send(result)
  })  
})   


module.exports=router;