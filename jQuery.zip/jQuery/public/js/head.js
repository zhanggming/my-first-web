$(function(){
    $.ajax({
       url:"http://meilele.applinzi.com/head",
        type:"get",
        dataType:"json",
        success: function() {
            var html=` <nav class="top-nav bg-floor ">
            <ul>
                <li><a href="javascript:;" class="my-red">北京站</a></li>
                <li><a href="javascript:;" class="my-gray">[切换]</a></li>
                <li><a href="http://meilele.applinzi.com/register.html" target="register" class="my-gray register" >请注册</a></li>
                <li><a href="http://meilele.applinzi.com/login.html"; target="login"  class="my-gray login ">请登录</a></li>
                <li><a href="javascript:;" class="my-gray">我的美乐乐</a></li>
            </ul>
            <ul>
                <li><a href="javascript:;" class="my-gray">购物车</a></li>
                <li><a href="javascript:;" class="my-gray">关注美乐乐</a></li>
                <li><a href="javascript:;" class="my-gray">帮助中心</a></li>
                <li><a href="javascript:;" class="my-gray">收藏本站</a></li>
            </ul>
            <ul><li><a href="javascript:;" class="my-gray">全国热线：4000098666</a></li></ul>
        </nav>
        <div class="cont"></div>
         <div class="top-floor">
             <img src="./img/index/head/logo2.png" alt=""/>
             <img src="./img/index/head/head.gif" alt=""/>
             <div class="top-input">
             <input type="text" class="my-input"/>
             <button class="btn">搜索</button>
             <p>抢20抵200翻倍红包&nbsp;床&nbsp;沙发&nbsp;餐桌椅&nbsp; 实木床&nbsp;床垫大促&nbsp;转角沙发&nbsp;灯饰</p>
             </div>
         </div>
         <div class="head-foot">
           <ul>
             <li class="active"><a href="http://meilele.applinzi.com/index.html">首页</a></li>
             <li><a href="javascript:;" target="index">商品分类</a></li>
             <li><a href="javascript:;">家具城</a></li>
             <li><a href="javascript:;">建材城</a></li> 
             <li><a href="javascript:;">家居家饰</a></li>
             <li><a href="javascript:;">团购</a></li>
             <li><a href="javascript:;">体验馆阅木</a></li> 
             <li><a href="javascript:;">晒家图览家居</a></li> 
            </ul>
            <div class="content">
            <div>
              <img src="./img/banner2/1.jpg">
            </div>
            <div>
               <img src="./img/banner2/2.jpg">
            </div>
             <div>
               <img src="./img/banner2/3.jpg">
            </div>
            <div>
              <img src="./img/banner2/4.jpg">
            </div>
            <div>
               <img src="./img/banner2/5.jpg">
            </div>
             <div>
               <img src="./img/banner2/6.jpg">
            </div>
            <div>
               <img src="./img/banner2/7.jpg">
            </div>
             <div>
               <img src="./img/banner2/8.jpg">
            </div>
            </div>
         </div>
        <div class="head-foot-b"></div>
        `;
           $("#header").html(html);
          
            $(".head-foot>ul>li").mouseenter(function(event) {
                $(this).addClass('active');
                $(this).siblings().removeClass('active');
     
             $('.content>div').eq($(this).index()).addClass('div_show');
                $('.content div').eq($(this).index()).siblings().removeClass('div_show');
            })
           /*var $li=$(".register")
           $li.click(function open1(){
            open("http://meilele.applinzi.com/register.html","register");
            })
            var $li=$(".login")
           $li.click(function open2(){
            open("http://meilele.applinzi.com/login.html","login");
            }) */
            ///登录
           /* var html="";
            html=`
         <div class="content">
             <a href="login.html">请登录</a>
          </div>`
           $(".cont").html(html);
                   var uname=sessionStorage.getItem("uname");
                   var $content=$(".content");
                   if(uname){
                       var html="欢迎回来"+uname+"<a href='http://meilele.applinzi.com/logout.html'>退出<a>";
                           $content.html(html);
                   }*/
        }
        })
})
 