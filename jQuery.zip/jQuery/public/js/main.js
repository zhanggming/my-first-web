     //图片banner2
     var a=1;
        function task(){
         /*图片*/
          a++;
          var $img=$("div.top-banner>ul.banner-img>li>a>img")
              var i=parseInt($img.attr("alt"));        
                if(i<9) i++;
                else i=1;
                $img.attr({
                   alt:i, src:`./img/banner2/${i}.jpg`
                 });
        }
       var n=setInterval(task,3000);
       function task1(){
        //点点
       var $li=$("div.top-banner>ul.ind>li.active2");
       $li.removeClass("active2");
       if($li.next().length!=0)
      
       $li.next().addClass("active2")
       else 
       $("div.top-banner>ul.ind>li:first-child").addClass("active2");
    }
    var n1=setInterval(task1,3000)
      //图片banner3
      var b=1;
      function task2(){
       /*图片*/
        b++;
        var $img=$("div.sencond-banner>ul.banner-img>li>a>img")
            var i=parseInt($img.attr("alt"));        
              if(i<8) i++;
              else i=1;
              $img.attr({
                 alt:i, src:`./img/banner3/${i}.jpg`
               });
      }
     var n=setInterval(task2,3000);
     function task3(){
      //点点
     var $li=$("div.sencond-banner>ul.ind>li.active2");
     $li.removeClass("active2");
     if($li.next().length!=0)
    
     $li.next().addClass("active2")
     else 
     $("div.sencond-banner>ul.ind>li:first-child").addClass("active2");
  }
  var n1=setInterval(task3,3000)