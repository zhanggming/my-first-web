//创建mysql连接池
const mysql = require('mysql');
var pool = mysql.createPool({
  host: 'w.rdc.sae.sina.com.cn',
  port:3306,
  user: '2xx20w2wjl',
  password: 'kw1yzml1241mz3khh3yl2x5lwwjmzjhzl4jyjylm',
  database:'app_meilele',
  connectionLimit: 20 
});
//把创建好的连接池导出
module.exports = pool;




