//使用express构建web服务器 --11:25
const express = require('express');
const bodyParser = require('body-parser');
/*引入路由模块*/
const index=require("./routes/index.route");
const foot=require("./routes/foot.route");
const head=require("./routes/head.route");
const user=require("./routes/user");

var app = express();
var server = app.listen(3000);
//使用body-parser中间件
app.use(bodyParser.urlencoded({extended:false}));
//托管静态资源到public目录下
app.use(express.static('public'))
//加载模块
const cors = require("cors");
app.use(cors({
    origin:["http://127.0.0.1:5500",
    "http://localhost:5500"],
    credentials:true
  }));
  //引入模块
  const session=require("express-session");
  //配置
  app.use(session({
    secret:"128位随机字符",//安全字符串
    resave:false,//每次请求是否更新数据
    saveUninitialized:true,//初始化时保存数据
    cookie:{
      maxAge:1000*60*60*8
    }
  }));
/*使用路由器来管理路由*/
app.use("/index",index);
app.use("/foot",foot);
app.use("/head",head);
app.use("/user",user);