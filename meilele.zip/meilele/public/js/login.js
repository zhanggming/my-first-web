var $phone=$("#phone");
      var $user=$("#user");
      //console.log($user);
      $phone.click(function(){
        var $table=$(".table");
        //console.log($table);
        var html="";
         html=`<div>
            <input type="text" placeholder="手机号"> 
          </div>  
          <div>
            <input type="text" placeholder="图形验证码"> 
          </div>
          <div>
            <input type="text" placeholder="获取短信验证码"> 
          </div> 
          <div>
              <input type="button" value="登录" class="btn">
              <div id="d1"></div>
          </div>`;
        $table.html(html);
      })
      //点击生成登录表单
      $user.click(function(){
        var $table=$(".table");
        //console.log($table);
        var html="";
        html=` <div>
                <input type="text" placeholder="邮箱/用户名/已验证手机" id="uname"> 
               </div>  
               <div>
                <input type="password" placeholder="密码" id="upwd"> 
                </div>
              <div>
               <input type="button" value="登录" class="btn">
               <div id="d1"></div>
              </div>`;
        $table.html(html);
         //元素生成之后验证登录
        $(".btn").click(function(){
				//console.log(123)
				var formData="uname="+uname.value+"&upwd="+upwd.value;
				$.ajax({
					url:"http://meilele.applinzi.com/user/login",
					type:"post",
					// 告诉jQuery不要去处理发送的数据
                    //processData : false,
                   // 告诉jQuery不要去设置Content-Type请求头
                  // contentType : false,
				   data :formData,
                   dataType: "json",
                  success: function(result) {
					  console.log(result)
	              if(result.code==1){
					  var html="";
					  html=`登录成功`
					  $("#d1").html(html);
				  }else{
            var html="";
					  html=`用户或密码有误`
					  $("#d1").html(html);
          }
					}})
		    	})
      })