$bigimg.mouseenter(function(){
    $bigimg.css("backgroundSize","1200px 1200px")
  }).mouseleave(function(){
    $bigimg.css("backgroundSize","cover").css("backgroundPosition","center center")
  });
  $bigimg.mousemove(function (e) {
    // console.log(1);
    var rate=1200/500;
    var mSize=250,smSize=500;
    var left=e.offsetX-mSize/2;
    var top=e.offsetY-mSize/2;
    left=left<0?0:left>smSize-mSize?smSize-mSize:left;
    top=top<0?0:top>smSize-mSize?smSize-mSize:top;
    $bigimg.css("backgroundPosition",-left*rate+"px "+-top*rate+"px");
  })