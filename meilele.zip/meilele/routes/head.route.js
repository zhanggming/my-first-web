const express=require("express");
const router=express.Router();
const pool=require("../pool");
router.get("/",(req,res)=>{
    //ssvar output={hid:[]}
   var output1={hids:[],gids:[]};

    res.writeHead(200,{
        "Access-Control-Allow-Origin":"*"
      })
      var sql=`select * from mll_head_title where hid!=0 order by hid`;  
      pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output1.hids=result;
    
      var sql=`select * from mll_head_img where gid!=0 order by gid`;
      pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output1.gids=result;
        
        res.write(JSON.stringify(output1));
        res.end();
        //console.log(output1)
        })
    
     }) 
        
})
module.exports=router;