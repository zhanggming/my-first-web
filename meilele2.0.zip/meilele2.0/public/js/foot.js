$(function(){
    $.ajax({
       url:"http://localhost:3000/foot",
        type:"get",
        dataType:"json",
        })
        
.then(res=>{
   // var {jid1s,jid2s}=output2;
   var html=`  <div class="foot-icon bg-floor my-gray my-small">
   <ul>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/o2o.png" alt=""/>
               <p class="my-gray my-small">美乐乐O2O</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/test.png" alt=""/>
               <p class="my-gray my-small">全国体验馆</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/cup.png" alt=""/>
               <p class="my-gray my-small">双重质检</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/sale.png" alt=""/>
               <p class="my-gray my-small">售后无忧</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/creat.png" alt=""/>
               <p class="my-gray my-small">原创设计</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/global.png" alt=""/>
               <p class="my-gray my-small">全球采购</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/name.png" alt=""/>
               <p class="my-gray my-small">万千口碑</p>
           </a>
       </li>
       <li>
           <a href="javascript:;">
               <img src="./img/index/foot/pepoles.png " alt=""/>
               <p class="my-gray my-small">团队优势</p></a>
       </li>
   </ul>
</div>


<div class="foot-index  my-gray my-small bg-floor">
       <div>
       <ul>
           <li>客服热线（9:00-22:00）</li>
           <li>4000098666</li>
           <li>美乐乐在全国体验店175家、样板间1家</li>
           <li>查看全国体验店</li>
           <li> 免费发送到手机</li>
       </ul>
       </div>

       <div>
       <ul>
           <li><h6>关于美乐乐</h6></li>
           <li>公司简介</li>
           <li>媒体聚焦</li>
           <li>体验馆</li>
           <li>诚聘英才</li>
           <li>招商加盟</li>
           <li>联系我们</li>
       </ul>
       </div>

       <div>
       <ul>
           <li><h6>新手指南</h6></li>
           <li>注册新用户</li>
           <li>会员级别</li>
           <li>金币说明</li>
           <li>乐币说明</li>
           <li>订购家具流程</li>
           <li>体验馆购买指导</li>
       </ul>
       </div>

       <div>
       <ul>
           <li> <h6>配送安装</h6></li>
           <li>收货指南</li>
           <li>体验馆服务费</li>
           <li>物流配送</li>
           <li>家具体积估算表</li>
       </ul>
       </div>

       <div>
       <ul>
           <li> <h6>售后服务</h6></li>
           <li>如何申请退款</li>
           <li>维修补件说明</li>
           <li>贵就赔</li>
           <li>30天无忧退换货</li>
           <li>建材保修政策</li>
           <li>家具保修</li>
       </ul>
       </div>

       <div>
       <ul>
           <li><h6> 购物保障</h6></li>
           <li>正品保证</li>
           <li>注册协议</li>
           <li>隐私保护</li>
           <li>免责声明</li>
       </ul>
       </div>

       <div>
          <ul><li><h6>官方微信</h6></li></ul> 
       </div>
</div>

<div class="foot-copy  my-gray bg-floor my-font">
       <div>
       <ul>
           <li>装修网|</li>
           <li>装修效果图|</li>
           <li>家具图片|</li>
           <li>家居资讯|</li>
           <li>生活百科|</li>
           <li>家私导购|</li>
           <li>品牌展厅|</li>
           <li>装修论坛|</li>
           <li>客服中心|</li>
           <li>网站地图|</li>
           <li>友情链接|</li>
           <li>更多</li>
           <li> 
           &copy;2005-2018&nbsp;美乐乐&nbsp;天津美维信息技术有限公司&nbsp;版权所有&nbsp;并保留所有权利。ICP备案证书号&nbsp;粤ICP备08008334号
          </li>
       </ul>
       </div>

       <div>
       <ul>
           <li>诚信网站</li>
           <li>认证联盟品牌官网</li>
           <li>可信网站信用评价</li>
           <li>经营网站备案信息</li>
       </ul>
       </div>
</div>`;
    $("#footer").html(html);
});
    })    