$(function(){
    $.ajax({
       url:"http://localhost:3000/head",
        type:"get",
        dataType:"json",
        })
    
.then(res=>{
   // var {hids,gids}=output1;
    var html=` <nav class="top-nav bg-floor ">
    <ul>
        <li><a href="javascript:;" class="my-red">北京站</a></li>
        <li><a href="javascript:;" class="my-gray">[切换]</a></li>
        <li><a href="javascript:;" class="my-gray">请注册</a></li>
        <li><a href="javascript:;" class="my-gray">请登录</a></li>
        <li><a href="javascript:;" class="my-gray">我的美乐乐</a></li>
    </ul>
    <ul>
        <li><a href="javascript:;" class="my-gray">购物车</a></li>
        <li><a href="javascript:;" class="my-gray">关注美乐乐</a></li>
        <li><a href="javascript:;" class="my-gray">帮助中心</a></li>
        <li><a href="javascript:;" class="my-gray">收藏本站</a></li>
    </ul>
    <ul><li><a href="javascript:;" class="my-gray">全国热线：4000098666</a></li></ul>
</nav>
 <div class="top-floor">
     <img src="./img/index/head/logo2.png" alt=""/>
     <img src="./img/index/head/head.gif" alt=""/>
     <div class="top-input">
     <input type="text" class="my-input"/>
     <button class="btn">搜索</button>
     <p>抢20抵200翻倍红包&nbsp;床&nbsp;沙发&nbsp;餐桌椅&nbsp; 实木床&nbsp;床垫大促&nbsp;转角沙发&nbsp;灯饰</p>
     </div>
 </div>
 <div class="head-foot">
   <p>商品分类&nbsp;首页&nbsp;家具城&nbsp;建材城&nbsp;家居家饰&nbsp;团购&nbsp;体验馆阅木&nbsp;晒家&nbsp;图览家居</p>
 </div>
<div class="head-foot-b"></div>`;
   /*var html=`<nav class="top-nav bg-floor ">
   <ul>
       <li><a href="javascript:;" class="my-red">${hids[0].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[1].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[2].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[3].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[4].title}</a></li>
   </ul>
   <ul>
       <li><a href="javascript:;" class="my-gray">${hids[5].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[6].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[7].title}</a></li>
       <li><a href="javascript:;" class="my-gray">${hids[8].title}</a></li>
   </ul>
   <ul><li><a href="javascript:;" class="my-gray">${hids[9].title}</a></li></ul>
   </nav>
   <div class="top-floor">
    <img src="${gids[0].img}" alt=""/>
    <img src="${gids[1].img}" alt=""/>
    <div class="top-input">
    <input type="text" class="my-input"/>
    <button class="btn">${hids[10].title}</button>
    <p>${hids[11].title}nbsp;${hids[12].title}&nbsp;${hids[13].title}&nbsp;${hids[14].title}&nbsp;${hids[15].title}&nbsp;${hids[16].title}&nbsp;${hids[17].title}&nbsp;${hids[18].title}</p>
    </div>
   </div>
   <div class="head-foot">
   <p>${hids[19].title}&nbsp;${hids[20].title}&nbsp;${hids[21].title}&nbsp;${hids[22].title}&nbsp;${hids[23].title}&nbsp;${hids[24].title}&nbsp;${hids[25].title}&nbsp;${hids[26].title}&nbsp;</p>
   </div>
   <div class="head-foot-b"></div>`*/
   $("#header").html(html);
});

})
 