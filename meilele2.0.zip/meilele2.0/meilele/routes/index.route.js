const express=require("express");
const router=express.Router();
const pool=require("../pool");


  router.get("/",(req,res)=>{
    var output={pids:[/*pid title*/],cids:[],fids:[],tids:[],kids:[],mids:[],nids:[],qids:[],vids:[]}

    res.writeHead(200,{
      "Access-Control-Allow-Origin":"*"
    });
    var sql=`select * from mll_index_product where pid!=0 order by pid `;
    pool.query(sql,[],(err,result)=>{
      if(err) console.log(err);
      output.pids=result;

      var sql=`select * from mll_index_carousel where cid!=0 order by cid`;
      pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.cids=result;

       var sql=`select * from mll_index_firstfloor where fid!=0 order by fid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.fids=result;
        
       var sql=`select * from mll_index_secondfloor where tid!=0 order by tid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.tids=result;

       var sql=`select * from mll_index_threefloor where kid!=0 order by kid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.kids=result;

       var sql=`select * from mll_index_threetitle where mid!=0 order by mid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.mids=result;

       var sql=`select * from mll_index_threeproduct where nid!=0 order by nid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.nids=result;
       var sql=`select * from mll_index_lastfloor where qid!=0 order by qid`;
       pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output.qids=result;
        
        var sql=`select * from mll_index_lastProduct where vid!=0 order by vid`;
        pool.query(sql,[],(err,result)=>{
          if(err) console.log(err);
          output.vids=result;
          res.write(JSON.stringify(output));
         res.end(); //console.log(output) 
        })
        }) 
      })  
      })
      })  
      })
      })
    })
    }) 
    })
      
      
   

module.exports=router;