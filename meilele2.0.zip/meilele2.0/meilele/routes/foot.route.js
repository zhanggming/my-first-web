const express=require("express");
const router=express.Router();
const pool=require("../pool");
router.get("/",(req,res)=>{
    //ssvar output={hid:[]}
   var output2={jid1s:[],jid2s:[]}

    res.writeHead(200,{
        "Access-Control-Allow-Origin":"*"
      })
     var sql=`select * from mll_foot_img where jid2!=0 order by jid2 `;
     pool.query(sql,[],(err,result)=>{
        if(err) console.log(err);
        output2.jid1s=result;

        var sql=`select * from mll_foot_title where jid1!=0 order by jid1 `;
        pool.query(sql,[],(err,result)=>{
           if(err) console.log(err);
           output2.jid2s=result;

        res.write(JSON.stringify(output2));
        res.end(); //console.log(output2) 
        })
    
     }) 
        
})
module.exports=router;